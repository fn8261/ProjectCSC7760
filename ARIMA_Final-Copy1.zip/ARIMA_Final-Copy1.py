#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


import pandas as pd
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')

# Load specific forecasting tools
from statsmodels.tsa.statespace.sarimax import SARIMAX

from statsmodels.graphics.tsaplots import plot_acf,plot_pacf # for determining (p,q) orders
from statsmodels.tsa.seasonal import seasonal_decompose      # for ETS Plots
from pmdarima import auto_arima                              # for determining ARIMA orders


# In[3]:


dataset = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\Compact - Copy.csv')
print(dataset)


# In[4]:


dataset.info()


# In[5]:


df = dataset[['Fuel (gal/hr)']]
df.head()


# In[6]:


df1 = dataset[[' Altitude (ft)',' Speed (mph)','Fuel (gal/hr)']]
df1.head()


# In[182]:


from pylab import rcParams


# In[183]:


# Load specific forecasting tools
from statsmodels.tsa.arima_model import ARMA,ARMAResults,ARIMA,ARIMAResults
from statsmodels.graphics.tsaplots import plot_acf,plot_pacf # for determining (p,q) orders
from pmdarima import auto_arima # for determining ARIMA orders


# Ignore harmless warnings
import warnings
warnings.filterwarnings("ignore")


# # augmented Dickey-Fuller Test

# In[184]:


from statsmodels.tsa.stattools import adfuller

def adf_test(series,title=''):
    """
    Pass in a time series and an optional title, returns an ADF report
    """
    print(f'Augmented Dickey-Fuller Test: {title}')
    result = adfuller(series.dropna(),autolag='AIC') # .dropna() handles differenced data
    
    labels = ['ADF test statistic','p-value','# lags used','# observations']
    out = pd.Series(result[0:4],index=labels)

    for key,val in result[4].items():
        out[f'critical value ({key})']=val
        
    print(out.to_string())          # .to_string() removes the line "dtype: float64"
    
    if result[1] <= 0.05:
        print("Strong evidence against the null hypothesis")
        print("Reject the null hypothesis")
        print("Data has no unit root and is stationary")
    else:
        print("Weak evidence against the null hypothesis")
        print("Fail to reject the null hypothesis")
        print("Data has a unit root and is non-stationary")


# In[185]:


dataset['Fuel (gal/hr)'].plot(figsize=(30,10));


# In[186]:


dataset1 = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\Compact - Copy.csv')
dataset1 = dataset1[:4014]
dataset1['Fuel (gal/hr)'].plot(figsize=(20,10));


# In[187]:


#df.tail()


# In[188]:


adf_test(dataset['Fuel (gal/hr)'])


# In[189]:


# Ignore harmless warnings
import warnings
warnings.filterwarnings("ignore")


# In[190]:


# For SARIMA Orders we set seasonal=True and pass in an m value
auto_arima(dataset['Fuel (gal/hr)'],seasonal=True,m=1).summary()


# # Use pmdarima.auto_arima to determine ARIMA Orders

# In[191]:


# For SARIMA Orders we set seasonal=True and pass in an m value
#auto_arima(dataset['Fuel rate (gal/hr)'],seasonal=True,m=7).summary()


# # Feature Scaling

# # Split the data into train/test sets

# In[192]:


training_set = df1.iloc[:9020]
print(training_set)


# In[193]:


testing_set = df1.iloc[9020:]
print(testing_set)


# In[194]:


training_set.tail()


# In[195]:


training_set.head()


# In[196]:


training_set.iloc[:,0:3]


# In[197]:


testing_set.iloc[:,0:3]


# In[198]:


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
training_set_scaled = sc.fit_transform(training_set)
print(training_set_scaled)


# In[199]:


testing_set_scaled = sc.transform(testing_set)
print(testing_set_scaled)


# In[200]:


import statsmodels.tsa.arima.model as stats


# In[201]:


model = SARIMAX(training_set_scaled[:,2:3],exog=training_set_scaled[:,0:2],order=(1,0,3),enforce_invertibility=False)
results = model.fit()
results.summary()


# In[202]:


# Obtain predicted values
start=len(training_set_scaled)
end=len(training_set_scaled)+len(testing_set_scaled)-1
exog_forecast =  testing_set_scaled[:,0:2]
#training_set_output[['Fuel rate (gal/hr)']]  # requires two brackets to yield a shape of (35,1)
predictions = results.predict(start,end, exog=exog_forecast,dynamic=False, typ='levels')
#rename('SARIMAX(1,0,3) Predictions')


# In[205]:


print (predictions)
y = predictions.reshape(-1,1)


# In[207]:


y = predictions.reshape(-1,1)
print(y)


# In[211]:


x=(testing_set_scaled[:,2:3])
print(x)


# In[213]:


from statsmodels.tools.eval_measures import mse,rmse,meanabs
error1x = mse(x, y)
error2x = rmse(x, y)
error3x = meanabs(x, y)

# Print new SARIMAX values
print(f'MSE Error: {error1x}')
print(f'RMSE Error: {error2x}')
print(f'meanabs Error: {error3x}')


# In[66]:


#model1 = stats.ARIMA(df1['Fuel rate (gal/hr)'],exog=df1['Altitude (ft)'],order=(3,0,1))
#results = model1.fit()
#exog_forecast = df1[12824:12885][['Altitude (ft)']]
#fcast = results.predict(len(df1),len(df1)+60,exog=exog_forecast).rename('SARIMAX(1,0,0)(2,0,0,7) Forecast')


# In[67]:


#print(fcast)


# In[72]:


dataset2 = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\test_Compact - Output.csv')
print(dataset2)


# In[73]:


real_value = dataset2.iloc[:,0:1].values
#print(real_value)


# In[74]:


def mape(real_value, predictions): 
    real_value, predictions = np.array(real_value[:,0]), np.array(predictions)
    return np.mean(np.abs((predictions - real_value) / (real_value))) * 100
print(mape(real_value, predictions))


# In[65]:


mpe = np.mean((predictions - real_value[:,0])/(real_value[:,0]))
import pprint
pprint.pprint({'mpe':mpe, 'MSE':error1x})


# In[66]:


mape = np.mean(np.abs(predictions - real_value[:,0])/np.abs(real_value[:,0]))
import pprint
pprint.pprint({'mape':mape, 'MSE':error1x})


# In[32]:


plt.figure(figsize=(10,8))
plt.scatter(real_value[:,0],predictions,s=1,alpha = 0.5, zorder =3)
m, b = np.polyfit(real_value[:,0], predictions, 1)
plt.plot(real_value[:,0], m*real_value[:,0]+b)
plt.plot([0,10],[0,10],zorder = 1, c = 'black', linestyle = '--', alpha =0.5)
plt.grid(linewidth = .5, linestyle = '--',zorder = 1)
plt.xlim(0,8)
plt.ylim(0,8)
plt.xlabel('True fuel rate (gal/hr)')
plt.ylabel('Predicted fuel rate (gal/hr)')
plt.show()
print('RMSE = ' + str(error2x))


# In[33]:


# Plot predictions against known values
title = 'Real Manufacturing and Trade Inventories'
ylabel='Chained 2012 Dollars'
xlabel='' # we don't really need a label here

ax = testing_set['Fuel rate (gal/hr)'].plot(legend=True,figsize=(12,6),title=title)
predictions.plot(legend=True)
ax.autoscale(axis='x',tight=True)
ax.set(xlabel=xlabel, ylabel=ylabel)
ax.yaxis.set_major_formatter(formatter);


# In[34]:


model = stats.ARIMA(df1['Fuel rate (gal/hr)'],exog=df1['Altitude (ft)'],order=(3,0,1))
results = model.fit()
exog_forecast = df1[12824:12885][['Altitude (ft)']]
fcast = results.predict(len(df1),len(df1)+60,exog=exog_forecast).rename('SARIMAX(1,0,0)(2,0,0,7) Forecast')


# In[35]:


from statsmodels.tools.eval_measures import mse,rmse,meanabs
error1x = mse(testing_set['Fuel rate (gal/hr)'], predictions)
error2x = rmse(testing_set['Fuel rate (gal/hr)'], predictions)
error3x = meanabs(testing_set['Fuel rate (gal/hr)'], predictions)

# Print new SARIMAX values
print(f'MSE Error: {error1x:11.10}')
print(f'RMSE Error: {error2x:11.10}')
print(f'meanabs Error: {error3x:11.10}')


# In[ ]:





# In[35]:


# Plot predictions against known values
title = 'Real Manufacturing and Trade Inventories'
ylabel='Chained 2012 Dollars'
xlabel='' # we don't really need a label here

ax = testing_set['Fuel rate (gal/hr)'].plot(legend=True,figsize=(12,6),title=title)
predictions.plot(legend=True)
ax.autoscale(axis='x',tight=True)
ax.set(xlabel=xlabel, ylabel=ylabel)
ax.yaxis.set_major_formatter(formatter);


# In[ ]:




