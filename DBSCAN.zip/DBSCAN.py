#!/usr/bin/env python
# coding: utf-8

# In[21]:


import pandas as pd
from pylab import rcParams
import numpy as np
import seaborn as sb
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import sklearn
from sklearn.cluster import DBSCAN
from collections import Counter
from sklearn.preprocessing import StandardScaler


# In[22]:


get_ipython().run_line_magic('matplotlib', 'inline')
rcParams ['figure.figsize'] = 14, 6
sb.set_style ('whitegrid')


# In[23]:


Data = pd.read_excel(r'C:\Users\hibat\Desktop\Compact (1)\Compact.xlsx')
print (Data)


# In[24]:


Data.info()


# In[31]:


Data["Time"] = pd.to_datetime(Data["Time"])

ax = Data.plot(x ="Time" , y="Fuel rate (gal/hr)" , kind="scatter" ,figsize=[15, 5], linewidth=0.1, alpha=0.6, color="#003399")

timeFmt = mdates.DateFormatter('%H:%M:%S')
ax.xaxis.set_major_formatter(timeFmt)
plt.xticks(rotation=90)


# In[32]:


plt.figure(figsize=(20, 5))
plt.plot( Data['Fuel rate (gal/hr)'], marker='.', linewidth=0, color = 'blue', label = 'Fuel Rate')
plt.ylabel('Fuel (gal/hr)')

plt.show()


# In[33]:


dbscan_data = Data[['Time_2', 'Fuel rate (gal/hr)']]
dbscan_data = dbscan_data.values.astype('float32', copy =False)
dbscan_data


# In[34]:


dbscan_data_scaler = StandardScaler().fit(dbscan_data)
dbscan_data = dbscan_data_scaler.transform(dbscan_data)
dbscan_data


# In[35]:


model = DBSCAN(eps = 0.30, min_samples = 5, metric= 'euclidean'). fit(dbscan_data)
model


# In[36]:


outliers_df = dbscan_data[model.labels_ == -1]
clusters_df = dbscan_data[model.labels_ != -1]
model.labels_


# In[37]:


colors = model.labels_
color_clusters = colors[colors != -1]
color_outliers = 'blue'

clusters = Counter(model.labels_)
print (clusters)
print (dbscan_data[model.labels_ == -1])
print ('number of clusters ={}'.format (len(clusters)-1))



# In[38]:


outliers_df = Data[model.labels_ == -1]
clusters_df = Data[model.labels_ != -1]
model.labels_
colors = model.labels_
color_clusters = colors[colors != -1]
color_outliers = 'blue'

clusters = Counter(model.labels_)
print (clusters)
print (Data[model.labels_ == -1])
print ('number of clusters ={}'.format (len(clusters)-1))


# In[40]:


clusters_df["Time"] = pd.to_datetime(clusters_df["Time"])
outliers_df["Time"] = pd.to_datetime(outliers_df["Time"])
fig = plt.figure()
ax = fig.add_axes([.1, .1, 1, 1])
ax.scatter (clusters_df['Time'], clusters_df['Fuel rate (gal/hr)'], c=color_clusters, edgecolors='black', s=20)
ax.scatter (outliers_df['Time'], outliers_df['Fuel rate (gal/hr)'], c=color_outliers, edgecolors='blue', s=50)
ax.set_ylabel('Fuel rate (gal/hr)', family= 'Arial', fontsize=15)
ax.set_xlabel('Time', family= 'Arial', fontsize=15)
plt.grid (which='major', color='#cccccc', alpha=0.45)
timeFmt = mdates.DateFormatter('%H:%M:%S')
ax.xaxis.set_major_formatter(timeFmt)
plt.xticks(rotation=90)
plt.show()




# In[ ]:





# In[ ]:





# In[ ]:




