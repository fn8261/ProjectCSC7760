#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import pandas as pd
tf.__version__


# # Importing Training Set

# In[2]:


dataset_train = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\train_Compact.csv')
print(dataset_train)


# In[3]:


dataset_train_output = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\train_Compact - Output.csv')
print(dataset_train_output)


# In[4]:


training_set = dataset_train.iloc[:, 0:3].values
print(training_set)


# In[5]:


training_set_output = dataset_train_output.iloc[:, 0:1].values
print(training_set_output)


# In[6]:


#new scaling
#from sklearn.preprocessing import MinMaxScaler
#sc= MinMaxScaler(feature_range = (0,1))
#training_set_scaled = sc.fit_transform (training_set)
#print (training_set_scaled)


# In[7]:


#sc_predict = MinMaxScaler()
#training_set_output_scaled = sc_predict.fit_transform(training_set_output[:,0:1])
#print(training_set_output_scaled)


# # Feature Scaling

# In[8]:


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
training_set_scaled = sc.fit_transform(training_set)
print(training_set_scaled)


# In[9]:


sc_predict = StandardScaler()
training_set_output_scaled = sc_predict.fit_transform(training_set_output[:,0:1])
print(training_set_output_scaled)


# Creating a data with timesteps 

# In[10]:


X_train = []
y_train = []
 
    
n_past = 60  # Number of past observations you want to use to predict the future
 
for i in range(n_past, len(training_set_scaled)):
    X_train.append(training_set_scaled[i - n_past:i, 0:3])
    y_train.append(training_set_output_scaled[i, 0:1])
X_train, y_train = np.array(X_train), np.array(y_train)
 


# In[11]:


print(X_train)


# In[12]:


X_train.shape


# In[13]:


print(y_train)


# In[14]:


y_train.shape


# In[15]:


X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 3)) #if 2 indicators, then use 2


# # Building the RNN

# # Import Libraries and packages from Keras

# In[16]:


from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout


# In[17]:


# Initializing the RNN
regressor = Sequential()


# In[18]:


# Adding fist LSTM layer and Drop out Regularization
regressor.add(LSTM(units = 50, return_sequences = True, input_shape = (X_train.shape[1], 3))) #2 is number of indicators
regressor.add (Dropout(0.2))


# In[19]:


regressor.add(LSTM(units = 50, return_sequences = True))
regressor.add (Dropout(0.2))


# In[20]:


regressor.add(LSTM(units = 50, return_sequences = True))
regressor.add (Dropout(0.2))


# In[21]:


regressor.add(LSTM(units = 50))
regressor.add (Dropout(0.2))


# #Output Layer

# In[22]:


regressor.add(Dense(units = 1))


# # Compiling the RNN

# In[23]:


regressor.compile(optimizer = 'adam', loss = 'mean_squared_error')


# #Fitting the RNN

# In[ ]:


mymodel = regressor.fit(X_train, y_train, epochs = 20, batch_size = 32)


# # Importing Test Set

# In[ ]:


dataset_test = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\test_Compact.csv')
test_set = dataset_test.iloc[:, 0:3].values
print (test_set)


# In[ ]:


dataset_test_output = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\test_Compact - Output.csv')
real_value = dataset_test_output.iloc[:, 0:1].values
print (real_value)


# In[ ]:


dataset_total = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\Compact - Copy.csv')
print (dataset_total)


# In[ ]:


inputs = dataset_total[len(dataset_total) - len(dataset_test)-60:].values
print(inputs)


# In[ ]:


inputs = inputs.reshape(-1,3)


# In[ ]:


inputs = sc.transform(inputs)
print(inputs)


# # Prediction and Visualizing Results of Test Set

# In[ ]:


X_test = []
for i in range (60, 3925):
    X_test.append(inputs[i-60:i, 0:3])

X_test = np.array(X_test)
print(X_test)


# In[ ]:


X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 3)) #if 2 indicators, then use 2


# In[ ]:


predicted_value = regressor.predict(X_test)
predicted_value = sc_predict.inverse_transform(predicted_value)
print(predicted_value)


# In[ ]:


import math
from sklearn.metrics import mean_squared_error
rmse = round (math.sqrt(mean_squared_error(real_value[:, 0:1], predicted_value[:, 0:1])),4)
print (rmse)


# In[ ]:


from sklearn.metrics import mean_absolute_error
mae = round (mean_absolute_error(real_value[:, 0:1], predicted_value[:, 0:1]),4)
print (mae)


# In[ ]:


from sklearn.metrics import mean_absolute_percentage_error
mape = round (mean_absolute_percentage_error(real_value[:, 0:1], predicted_value[:, 0:1]),4)
print (mape)


# In[ ]:


import pandas as pd
import numpy as np
  
# Define the function to return the SMAPE value
def calculate_smape(real_value, predicted_value) -> float:
  
    # Convert actual and predicted to numpy
    # array data type if not already
    if not all([isinstance(real_value, np.ndarray), 
                isinstance(predicted_value, np.ndarray)]):
        real_value, predicted_value = np.array(real_value),
        np.array(predicted_value)
  
    return round(
        np.mean(
            np.abs(predicted_value - real_value) / 
            ((np.abs(predicted_value) + np.abs(real_value)))
        )*100, 3
    )
  
print("np array :", 
          calculate_smape(real_value, predicted_value), "%")


# In[43]:


MAPE = np.mean(np.abs((real_value[:, 0:1]-predicted_value[:, 0:1])/real_value[:, 0:1]))*100
print("MAPE:", MAPE)


# In[44]:


from sklearn.metrics import mean_absolute_percentage_error
mape = round (mean_absolute_percentage_error(real_value[:, 0:1], predicted_value[:, 0:1]),5)
print (mape)


# In[45]:


def mape(real_value, predicted_value): 
    real_value, predicted_value = np.array(real_value[:, 0:1]), np.array(predicted_value[:, 0:1])
    return np.mean(np.abs((real_value - predicted_value) / (real_value))) * 100
print(mape(real_value, predicted_value))


# In[224]:


plt.figure(figsize=(10,8))
plt.scatter(real_value[:, 0],predicted_value[:, 0],s=1,alpha = 0.5, zorder =3)
m, b = np.polyfit(real_value[:, 0], predicted_value[:, 0], 1)
plt.plot(real_value[:, 0], m*real_value[:, 0]+b)
plt.plot([0,10],[0,10],zorder = 1, c = 'black', linestyle = '--', alpha =0.5)
plt.grid(linewidth = .5, linestyle = '--',zorder = 1)
plt.xlim(0,8)
plt.ylim(0,8)
plt.xlabel('True fuel rate (gal/hr)')
plt.ylabel('Predicted fuel rate (gal/hr)')
plt.show()
print('RMSE = ' + str(rmse))
print('MAE = ' + str(mae))
print('MAPE = ' + str(MAPE))


# In[46]:


plt.figure(figsize=(20, 10))
plt.plot (real_value[:, 0:1], color = 'red', label = 'Real')
plt.plot (predicted_value[:, 0:1], color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()


# In[47]:


plt.figure(figsize=(20, 10))
plt.plot (real_value[:, 0:1], color = 'red', label = 'Real')
plt.plot (predicted_value[:, 0:1], color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()


# In[48]:


df = pd.DataFrame (predicted_value[:,:])
df.to_excel(r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\LSTM\graph_compact_LSTM_600.xlsx', index = False)


# In[259]:


dataset2 = pd.read_excel (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\LSTM\graph_compact_LSTM_600.xlsx')
print(dataset2)


# In[261]:


x1 = dataset2.iloc[:, 0:1].values
print(x1)


# In[262]:


y1 = dataset2.iloc[:, 1:2].values
print(y1)


# In[263]:


plt.figure(figsize=(20, 10))
plt.plot (x1[:, 0:1], color = 'red', label = 'Real')
plt.plot (y1[:, 0:1], color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()
print('RMSE = ' + str(rmse))
print('MAE = ' + str(mae))
print('MAPE = ' + str(MAPE))


# In[61]:


plt.figure(figsize=(20, 10))
plt.plot (x1[:, 0:1], color = 'red', label = 'Real')
plt.plot (y1[:, 0:1], color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()
print('RMSE = ' + str(rmse))
print('MAE = ' + str(mae))
print('MAPE = ' + str(MAPE))


# In[52]:


from sklearn.metrics import r2_score
r2_score (real_value, predicted_value)


# In[85]:


plt.figure(figsize=(10,8))
plt.scatter(real_value[:, 0],predicted_value[:, 0],s=1,alpha = 0.5, zorder =3)
m, b = np.polyfit(real_value[:, 0], predicted_value[:, 0], 1)
plt.plot(real_value[:, 0], m*real_value[:, 0]+b)
plt.plot([0,10],[0,10],zorder = 1, c = 'black', linestyle = '--', alpha =0.5)
plt.grid(linewidth = .5, linestyle = '--',zorder = 1)
plt.xlim(0,8)
plt.ylim(0,8)
plt.xlabel('True fuel rate (gal/hr)')
plt.ylabel('Predicted fuel rate (gal/hr)')
plt.show()
print('RMSE = ' + str(rmse))


# # Prediction and Visualizing Result of Chattanooga Set

# In[34]:


df = pd.DataFrame (predicted_value[:,:])
df.to_csv(r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\LSTM-3.csv', index = False)


# In[35]:


Chattanooga = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\Chattanooga.csv')
Chattanooga_test = Chattanooga.iloc[:, 0:3].values
print (Chattanooga_test)


# In[36]:


Chattanooga_test_scaled = sc.fit_transform(Chattanooga_test)
print(Chattanooga_test_scaled)


# In[37]:


X_test = []
for i in range(60, 56317):
    X_test.append(Chattanooga_test_scaled[i-60:i, 0:3])
X_test = np.array(X_test)
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 3)) #if 2 indicators, then use 2
print(X_test)


# In[38]:


predicted_fuel = regressor.predict(X_test)
predicted_fuel = sc_predict.inverse_transform(predicted_fuel)


# In[39]:


print(predicted_fuel)


# In[40]:


df = pd.DataFrame (predicted_fuel[:,:])
df.to_excel(r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\predicted_fuel1.xlsx', index = False)


# In[41]:


plt.figure(figsize=(20, 5))
plt.plot (predicted_fuel, color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()


# In[42]:


dataset1 = pd.read_csv (r'C:\Users\hibat\Desktop\Fuel_model\Compact\Compact\graph_compact_LSTM_3.csv')
x = dataset1.iloc[:, 0:1].values
print(x)
y = dataset1.iloc[:, 1:2].values
print(y)


# In[44]:


plt.figure(figsize=(20, 10))
plt.plot (x[:, 0:1], color = 'red', label = 'Real')
plt.plot (y[:, 0:1], color = 'blue', label = 'Predicted')
plt.xlabel('Time')
plt.ylabel('Fuel (gal/hr)')
plt.legend()
plt.show()


# In[ ]:




